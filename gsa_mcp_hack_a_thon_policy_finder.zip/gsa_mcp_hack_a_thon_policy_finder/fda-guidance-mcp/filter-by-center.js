// Filter documents by center
import { SearchEngine } from './build/search-engine.js';
import fs from 'fs/promises';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

async function main() {
  const centerName = process.argv.slice(2).join(' ');

  if (!centerName) {
    console.error('Usage: node filter-by-center.js <center name>');
    console.error('Example: node filter-by-center.js CDER');
    console.error('Example: node filter-by-center.js "Center for Drug Evaluation"');
    process.exit(1);
  }

  const searchEngine = new SearchEngine();
  const dataPath = path.join(__dirname, 'data', 'all_documents.json');

  try {
    const content = await fs.readFile(dataPath, 'utf-8');
    const documents = JSON.parse(content);
    searchEngine.loadDocuments(documents);

    const results = searchEngine.searchByCenter(centerName);

    console.log(`Documents from: ${centerName}`);
    console.log('='.repeat(80));
    console.log('');
    console.log(`Found ${results.length} documents:\n`);

    results.forEach((doc, idx) => {
      console.log(`${idx + 1}. ${doc.documentName}`);
      console.log(`   Center: ${doc.centerOrOfficeName}`);
      console.log(`   Status: ${doc.documentStatus} | Date: ${doc.date}`);
      console.log(`   Sections: ${doc.sections.length}`);
      console.log('');
    });

  } catch (error) {
    console.error('Error:', error.message);
    process.exit(1);
  }
}

main();
