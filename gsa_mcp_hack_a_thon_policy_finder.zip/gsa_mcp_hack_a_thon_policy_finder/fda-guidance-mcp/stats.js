// Display statistics about extracted documents
import { SearchEngine } from './build/search-engine.js';
import fs from 'fs/promises';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

async function main() {
  const searchEngine = new SearchEngine();
  const dataPath = path.join(__dirname, 'data', 'all_documents.json');

  try {
    // Load documents
    const content = await fs.readFile(dataPath, 'utf-8');
    const documents = JSON.parse(content);
    searchEngine.loadDocuments(documents);

    // Get statistics
    const stats = searchEngine.getStatistics();

    console.log('FDA Guidance Document Statistics');
    console.log('='.repeat(80));
    console.log('');
    console.log(`Total Documents: ${stats.totalDocuments}`);
    console.log('');
    console.log('By Status:');
    console.log(`  Draft: ${stats.draftCount}`);
    console.log(`  Final: ${stats.finalCount}`);
    console.log(`  Unknown: ${stats.unknownCount}`);
    console.log('');
    console.log('By Center/Office:');

    const centers = Object.entries(stats.centerCounts)
      .sort((a, b) => b[1] - a[1]);

    centers.forEach(([center, count]) => {
      console.log(`  ${center}: ${count}`);
    });
    console.log('');

    // Additional document details
    console.log('Document List:');
    console.log('-'.repeat(80));

    documents.forEach((doc, idx) => {
      console.log(`${idx + 1}. ${doc.documentName}`);
      console.log(`   ${doc.centerOrOfficeName} | ${doc.documentStatus} | ${doc.date}`);
      console.log(`   Sections: ${doc.sections.length}`);
      console.log('');
    });

  } catch (error) {
    if (error.code === 'ENOENT') {
      console.error('Error: No documents found.');
      console.error('Please run extraction first: node extract-pdfs.js');
    } else {
      console.error('Error:', error.message);
    }
    process.exit(1);
  }
}

main();
