// Extract a single PDF file
import { PDFExtractor } from './build/pdf-extractor.js';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

async function main() {
  // Get PDF filename from command line argument
  const pdfFileName = process.argv[2];

  if (!pdfFileName) {
    console.error('Usage: node extract-single.js <pdf-filename>');
    console.error('Example: node extract-single.js bioequivalence-guidance.pdf');
    process.exit(1);
  }

  const extractor = new PDFExtractor();
  const pdfPath = path.join(__dirname, 'pdfs', pdfFileName);
  const dataPath = path.join(__dirname, 'data');

  console.log(`Extracting: ${pdfFileName}`);
  console.log('');

  try {
    const result = await extractor.extractPDF(pdfPath);

    if (!result.success || !result.document) {
      console.error('Extraction failed:');
      result.errors?.forEach(err => console.error(`  - ${err}`));
      process.exit(1);
    }

    const doc = result.document;

    console.log('✓ Extraction successful!');
    console.log('');
    console.log(`Document: ${doc.documentName}`);
    console.log(`Center: ${doc.centerOrOfficeName}`);
    console.log(`Status: ${doc.documentStatus}`);
    console.log(`Date: ${doc.date}`);
    console.log(`Total Pages: ${doc.metadata?.totalPages || 'Unknown'}`);
    console.log(`Sections: ${doc.sections.length}`);
    console.log('');

    if (result.warnings && result.warnings.length > 0) {
      console.log('Warnings:');
      result.warnings.forEach(warn => console.log(`  ⚠ ${warn}`));
      console.log('');
    }

    // Display sections
    console.log('Document Structure:');
    doc.sections.forEach((section, idx) => {
      console.log(`  ${idx + 1}. ${section.sectionTitle}`);
      section.subsections.forEach((sub, subIdx) => {
        console.log(`     ${idx + 1}.${subIdx + 1} ${sub.subsectionTitle}`);
      });
    });
    console.log('');

    // Save to JSON
    const sanitizedName = doc.documentName
      .replace(/[^a-zA-Z0-9\s-]/g, '')
      .replace(/\s+/g, '_')
      .slice(0, 100);
    const outputPath = path.join(dataPath, `${sanitizedName}.json`);
    await extractor.saveToJSON(doc, outputPath);

    console.log(`Saved to: ${sanitizedName}.json`);

  } catch (error) {
    console.error('Error:', error.message);
    process.exit(1);
  }
}

main();
