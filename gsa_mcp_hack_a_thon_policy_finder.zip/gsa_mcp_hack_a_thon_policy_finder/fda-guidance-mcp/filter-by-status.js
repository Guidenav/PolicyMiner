// Filter documents by status (draft/final)
import { SearchEngine } from './build/search-engine.js';
import fs from 'fs/promises';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

async function main() {
  const status = process.argv[2];

  if (!status || !['draft', 'final', 'unknown'].includes(status.toLowerCase())) {
    console.error('Usage: node filter-by-status.js <status>');
    console.error('Status must be: draft, final, or unknown');
    console.error('Example: node filter-by-status.js draft');
    process.exit(1);
  }

  const searchEngine = new SearchEngine();
  const dataPath = path.join(__dirname, 'data', 'all_documents.json');

  try {
    const content = await fs.readFile(dataPath, 'utf-8');
    const documents = JSON.parse(content);
    searchEngine.loadDocuments(documents);

    const results = searchEngine.searchByStatus(status.toLowerCase());

    console.log(`Documents with status: ${status}`);
    console.log('='.repeat(80));
    console.log('');
    console.log(`Found ${results.length} documents:\n`);

    results.forEach((doc, idx) => {
      console.log(`${idx + 1}. ${doc.documentName}`);
      console.log(`   Center: ${doc.centerOrOfficeName}`);
      console.log(`   Status: ${doc.documentStatus} | Date: ${doc.date}`);
      console.log('');
    });

  } catch (error) {
    console.error('Error:', error.message);
    process.exit(1);
  }
}

main();
