// Interactive menu for FDA Guidance MCP Server
import readline from 'readline';
import { exec } from 'child_process';
import { promisify } from 'util';

const execAsync = promisify(exec);

const rl = readline.createInterface({
  input: process.stdin,
  output: process.stdout
});

function question(prompt) {
  return new Promise(resolve => rl.question(prompt, resolve));
}

function showMenu() {
  console.clear();
  console.log('='.repeat(80));
  console.log('FDA GUIDANCE MCP SERVER - MAIN MENU');
  console.log('='.repeat(80));
  console.log('');
  console.log('1. Extract all PDFs');
  console.log('2. Extract single PDF');
  console.log('3. Search documents');
  console.log('4. View statistics');
  console.log('5. Filter by center');
  console.log('6. Filter by status');
  console.log('7. Exit');
  console.log('');
}

async function runCommand(command) {
  try {
    const { stdout, stderr } = await execAsync(command);
    if (stdout) console.log(stdout);
    if (stderr) console.error(stderr);
  } catch (error) {
    console.error('Error:', error.message);
  }
}

async function main() {
  let running = true;

  while (running) {
    showMenu();
    const choice = await question('Enter your choice (1-7): ');
    console.log('');

    try {
      switch (choice.trim()) {
        case '1':
          console.log('Extracting all PDFs...\n');
          await runCommand('node extract-pdfs.js');
          break;

        case '2':
          const pdfFile = await question('Enter PDF filename: ');
          console.log('');
          await runCommand(`node extract-single.js "${pdfFile}"`);
          break;

        case '3':
          const query = await question('Enter search query: ');
          console.log('');
          await runCommand(`node search.js ${query}`);
          break;

        case '4':
          console.log('Loading statistics...\n');
          await runCommand('node stats.js');
          break;

        case '5':
          const center = await question('Enter center name (e.g., CDER): ');
          console.log('');
          await runCommand(`node filter-by-center.js ${center}`);
          break;

        case '6':
          const status = await question('Enter status (draft/final): ');
          console.log('');
          await runCommand(`node filter-by-status.js ${status}`);
          break;

        case '7':
          running = false;
          console.log('Goodbye!');
          break;

        default:
          console.log('Invalid choice. Please try again.');
      }

      if (running && choice !== '7') {
        await question('\nPress Enter to continue...');
      }

    } catch (error) {
      console.error('Error:', error.message);
      await question('\nPress Enter to continue...');
    }
  }

  rl.close();
}

main();
