// Extract all PDFs from the pdfs directory
import { PDFExtractor } from './build/pdf-extractor.js';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

async function main() {
  const extractor = new PDFExtractor();

  const pdfPath = path.join(__dirname, 'pdfs');
  const dataPath = path.join(__dirname, 'data');

  console.log('Starting PDF extraction...');
  console.log(`PDF Directory: ${pdfPath}`);
  console.log(`Data Directory: ${dataPath}`);
  console.log('');

  try {
    // Process all PDFs
    const documents = await extractor.processDirectory(pdfPath);

    console.log(`\nSuccessfully processed ${documents.length} documents:`);
    console.log('');

    // Display summary
    documents.forEach((doc, index) => {
      console.log(`${index + 1}. ${doc.documentName}`);
      console.log(`   Center: ${doc.centerOrOfficeName}`);
      console.log(`   Status: ${doc.documentStatus}`);
      console.log(`   Date: ${doc.date}`);
      console.log(`   Sections: ${doc.sections.length}`);
      console.log('');
    });

    // Save individual files
    for (const doc of documents) {
      const sanitizedName = doc.documentName
        .replace(/[^a-zA-Z0-9\s-]/g, '')
        .replace(/\s+/g, '_')
        .slice(0, 100);
      const outputPath = path.join(dataPath, `${sanitizedName}.json`);
      await extractor.saveToJSON(doc, outputPath);
      console.log(`Saved: ${sanitizedName}.json`);
    }

    // Save combined file
    const allDocsPath = path.join(dataPath, 'all_documents.json');
    await extractor.saveAllToJSON(documents, allDocsPath);
    console.log(`\nSaved combined file: all_documents.json`);

    console.log('\n✓ Extraction complete!');

  } catch (error) {
    console.error('Error during extraction:', error.message);
    process.exit(1);
  }
}

main();
