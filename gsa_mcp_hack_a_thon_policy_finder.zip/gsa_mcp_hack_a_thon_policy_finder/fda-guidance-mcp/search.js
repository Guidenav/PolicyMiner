// Search extracted guidance documents
import { SearchEngine } from './build/search-engine.js';
import fs from 'fs/promises';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

async function main() {
  const query = process.argv.slice(2).join(' ');

  if (!query) {
    console.error('Usage: node search.js <search query>');
    console.error('Example: node search.js clinical trial endpoints');
    process.exit(1);
  }

  const searchEngine = new SearchEngine();
  const dataPath = path.join(__dirname, 'data', 'all_documents.json');

  try {
    // Load documents
    console.log('Loading documents...');
    const content = await fs.readFile(dataPath, 'utf-8');
    const documents = JSON.parse(content);
    searchEngine.loadDocuments(documents);

    console.log(`Loaded ${documents.length} documents`);
    console.log('');
    console.log(`Searching for: "${query}"`);
    console.log('='.repeat(80));
    console.log('');

    // Perform search
    const results = searchEngine.smartSearch(query, 20);

    if (results.length === 0) {
      console.log('No results found.');
      return;
    }

    console.log(`Found ${results.length} results:\n`);

    // Display results
    results.forEach((result, idx) => {
      console.log(`${idx + 1}. ${result.documentName}`);
      console.log(`   Center: ${result.centerOrOfficeName}`);
      console.log(`   Status: ${result.documentStatus} | Date: ${result.date}`);
      console.log(`   Location: ${result.matchLocation}`);
      console.log(`   Match Type: ${result.matchType} | Score: ${result.relevanceScore}`);
      console.log(`   Context: ${result.matchedText}`);
      console.log('');
    });

  } catch (error) {
    if (error.code === 'ENOENT') {
      console.error('Error: No documents found.');
      console.error('Please run extraction first: node extract-pdfs.js');
    } else {
      console.error('Error:', error.message);
    }
    process.exit(1);
  }
}

main();
